Voici un exemple de projet unity enti�rement cod� en utilisant le patron de conception ECS.

L'id�e �tait de montrer qu'� l'aide de ce patron de conception il est possible aux jeux 
d'avoir un nombre impressionnnant d'IA affich�es � l'�cran en m�me temps. Dans notre 
exemple, 10'000 poissons low poly sont initialis�s au m�me moment et parcourent l'�cran
dans des directions al�atoires. Des v�rifications des positions sont faites � chaque frame.

N'h�sitez pas � changer les nombre de poissons et � voir par vous-m�me les changements de performance!

R�sultats:
FPS moyen de 60 avec 1000.
FPS moyen de 10 avec 10'000 ou plus.

Par Samuel Masson (1632010).