﻿using UnityEngine;

namespace Movements
{
    public class FishTargeter : MonoBehaviour
    {
        public Vector3 targetPosition = Vector3.zero;
    }
}